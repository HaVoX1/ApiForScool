using Microsoft.EntityFrameworkCore;
using StudyPlanerSamPlusEFGame.Data;
using StudyPlanner.dtos;
using StudyPlanner.Models;

namespace StudyPlanerSamPlusEFGame.Endpoints_Controller_;

public static class SubjectsEndpoints
{
    public static void MapSubjectsEndpoint(this WebApplication app)
    {
        var group = app.MapGroup("/api/subjects");


        // GET /api/subjects
        group.MapGet("/", async (StudyPlannerDbContext db) =>
        {
            var list = await db.Subjects
                .OrderBy(s => s.Name)
                .Select(s => new SubjectDto(s.Name, s.Id))
                .ToListAsync();

            return Results.Ok(list);
        });
        
        group.MapGet("/{id}", async (int id, StudyPlannerDbContext db) =>
        {
            var list = await db.Subjects
                .Where(s => s.Id == id)
                .Select(s => new SubjectById(s.Id,s.Name))
                .FirstOrDefaultAsync();
            
            return Results.Ok(list);
        });
        group.MapPut("/{id}", async (int id, StudyPlannerDbContext db,  CreateNewNameSub dto) =>
        {
            var list = await db.Subjects.FindAsync(id);
            
            if (list is null) return Results.NotFound();

            list.Name = dto.ToString();
            
            await db.SaveChangesAsync();
            return Results.NoContent();
        });

    }
}
