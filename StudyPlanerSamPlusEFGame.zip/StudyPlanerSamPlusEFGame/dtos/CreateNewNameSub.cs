namespace StudyPlanner.dtos;

public class CreateNewNameSub(    
        string name
    );